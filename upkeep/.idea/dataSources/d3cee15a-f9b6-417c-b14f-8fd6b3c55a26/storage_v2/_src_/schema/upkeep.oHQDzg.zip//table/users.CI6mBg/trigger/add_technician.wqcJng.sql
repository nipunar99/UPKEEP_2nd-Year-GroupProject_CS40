create definer = root@localhost trigger add_technician
    after insert
    on users
    for each row
BEGIN
  IF NEW.user_role = 'technician' THEN
    INSERT INTO technicians (user_id)
    VALUES (NEW.user_id);
  END IF;
END;

