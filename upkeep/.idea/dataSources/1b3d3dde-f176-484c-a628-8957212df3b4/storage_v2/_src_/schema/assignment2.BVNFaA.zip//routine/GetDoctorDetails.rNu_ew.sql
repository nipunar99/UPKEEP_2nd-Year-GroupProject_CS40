create
    definer = root@localhost procedure GetDoctorDetails(IN doctorID int)
BEGIN
  SELECT Doctor_ID, CONCAT(Fname, ' ', Lname) AS "Doctor's Full Name"
  FROM DoctorDetails
  WHERE Doctor_ID = doctorID;
END;

